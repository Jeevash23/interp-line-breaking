| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1306 |
| AUROC | 0.988 |
| Separation | 3.526 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L4H0,L4H1,L5H13,L6H2,L7H15 | 150 | -2.763 (-3.005, -2.530) | 70.4% (65.3%, 75.6%) | -0.2% (0.0%) | pass |
| X, newline writers (no dissociation predicted) | L5H12,L5H13,L6H2 | 135 | 1.260 (1.091, 1.439) | 44.2% (38.7%, 49.7%) | -0.6% (2.2%) | pass |
| R, readers (Lw 6) | L7H14,L15H3,L17H6,L22H3 | 135 | 0.519 (0.410, 0.627) | 78.2% (71.3%, 87.1%) | -0.4% (0.7%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| X: L5H12,L5H13,L6H2 | 52.3% (49.8%, 54.9%) | 0.980 |

T, token correctors: L4H1 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 5078 | 0.015 (-0.022, 0.052) | 0.254 (0.211, 0.300) | 0.238 (0.214, 0.268) | 0.015 (0.019) | pass |
| 60 | 3099 | -0.002 (-0.038, 0.041) | 0.184 (0.153, 0.219) | 0.186 (0.152, 0.216) | -0.002 (0.001) | pass |
| 80 | 2115 | -0.005 (-0.032, 0.026) | 0.128 (0.100, 0.161) | 0.133 (0.107, 0.163) | -0.005 (-0.003) | pass |

Verdicts: C pass, T pass, X pass, R pass
