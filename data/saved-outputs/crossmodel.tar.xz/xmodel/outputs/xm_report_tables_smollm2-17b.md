| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1191 |
| AUROC | 0.986 |
| Separation | 3.344 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L5H21,L7H22,L9H7 | 146 | -2.623 (-2.856, -2.402) | 72.9% (69.0%, 77.3%) | 0.1% (0.3%) | pass |
| S, stored length | L5H21,L9H7,L6H25,L2H17 | 149 | 1.232 (1.068, 1.395) | 36.2% (29.0%, 43.3%) | 0.5% (4.5%) | pass |
| R, readers (Lw 10) | L11H21 | 149 | 0.745 (0.634, 0.854) | 47.7% (42.8%, 52.2%) | -0.5% (0.0%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| S: L5H21,L9H7,L6H25,L2H17 | 86.0% (82.2%, 89.9%) | 0.983 |

T, token correctors: L5H21,L3H2 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 4757 | 0.037 (0.005, 0.069) | 0.229 (0.193, 0.266) | 0.192 (0.157, 0.227) | 0.038 (0.044) | pass |
| 60 | 2840 | 0.004 (-0.023, 0.033) | 0.225 (0.192, 0.264) | 0.221 (0.192, 0.255) | 0.004 (0.006) | pass |
| 80 | 1931 | 0.008 (-0.014, 0.030) | 0.179 (0.142, 0.221) | 0.171 (0.137, 0.211) | 0.008 (0.009) | pass |

Verdicts: C pass, T pass, S pass, R pass
