| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1253 |
| AUROC | 0.984 |
| Separation | 3.092 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L1H1,L1H6,L2H5,L3H0,L3H5,L6H3 | 150 | -3.431 (-3.650, -3.207) | 65.3% (61.9%, 68.8%) | 2.3% (8.1%) | pass |
| S, stored length | L3H5,L6H3,L9H4,L10H1,L1H1,L2H6 | 150 | 1.063 (0.922, 1.202) | 54.5% (46.3%, 62.6%) | -11.4% (4.9%) | pass |
| R, readers (Lw 6) | L12H6,L9H0,L7H3 | 150 | 0.588 (0.466, 0.708) | 49.9% (43.2%, 57.8%) | 0.6% (1.4%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| S: L3H5,L6H3,L9H4,L10H1,L1H1,L2H6 | 92.7% (86.8%, 99.2%) | 0.979 |

T, token correctors: L0H0,L1H1,L1H6 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 4978 | 0.048 (-0.012, 0.109) | 0.463 (0.388, 0.541) | 0.415 (0.356, 0.481) | 0.075 (0.134) | pass |
| 60 | 3033 | 0.074 (0.038, 0.105) | 0.380 (0.314, 0.456) | 0.306 (0.221, 0.400) | 0.066 (0.105) | pass |
| 80 | 2106 | 0.036 (-0.000, 0.072) | 0.266 (0.219, 0.321) | 0.229 (0.177, 0.289) | 0.039 (0.067) | pass |

Verdicts: C pass, T pass, S pass, R pass
