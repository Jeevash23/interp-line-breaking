| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1354 |
| AUROC | 0.984 |
| Separation | 2.948 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L2H1,L3H1,L3H2,L6H1 | 150 | -3.098 (-3.328, -2.855) | 59.1% (55.3%, 63.2%) | -0.0% (0.1%) | pass |
| S, stored length | L2H1,L3H1,L3H2 | 150 | 1.073 (0.903, 1.240) | 37.1% (30.8%, 42.7%) | 1.2% (9.4%) | pass |
| R, readers (Lw 3) | L6H4,L4H8,L6H6 | 150 | 0.669 (0.528, 0.806) | 96.4% (88.6%, 107.2%) | -0.1% (0.0%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| S: L2H1,L3H1,L3H2 | 85.1% (79.4%, 90.7%) | 0.979 |

T, token correctors: L1H8,L1H9,L2H1,L3H1 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 5323 | 0.035 (0.007, 0.063) | 0.160 (0.125, 0.196) | 0.124 (0.085, 0.165) | 0.027 (0.047) | pass |
| 60 | 3213 | 0.025 (-0.006, 0.052) | 0.208 (0.168, 0.259) | 0.183 (0.133, 0.242) | 0.018 (0.037) | pass |
| 80 | 2209 | 0.010 (-0.011, 0.031) | 0.127 (0.095, 0.169) | 0.117 (0.075, 0.167) | 0.003 (0.012) | pass |

Verdicts: C pass, T pass, S pass, R pass
