| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1192 |
| AUROC | 0.987 |
| Separation | 3.663 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L6H3,L12H3 | 150 | -3.065 (-3.364, -2.772) | 68.3% (61.7%, 75.5%) | 0.3% (5.2%) | pass |
| S, stored length | L6H1,L6H3,L7H6 | 150 | 1.578 (1.397, 1.753) | 43.8% (37.1%, 50.2%) | 1.9% (6.6%) | pass |
| R, readers (Lw 7) | L9H5,L12H3 | 150 | 0.996 (0.871, 1.129) | 50.5% (45.1%, 56.6%) | -0.1% (2.1%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| S: L6H1,L6H3,L7H6 | 70.2% (63.9%, 75.8%) | 0.978 |

T, token correctors: L6H3 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 4919 | 0.001 (-0.037, 0.042) | 0.390 (0.341, 0.441) | 0.388 (0.333, 0.448) | 0.004 (0.058) | pass |
| 60 | 2975 | 0.032 (-0.009, 0.076) | 0.375 (0.329, 0.425) | 0.343 (0.290, 0.395) | 0.031 (0.068) | pass |
| 80 | 2039 | 0.006 (-0.025, 0.037) | 0.311 (0.264, 0.362) | 0.305 (0.254, 0.362) | 0.004 (0.030) | pass |

Verdicts: C pass, T pass, S pass, R pass
