| Model | Protocol | Gate AUROC | C, counters | T, token correctors (per token, widths 40/60/80) | S, stored length (decision kept) | X, newline writers (decision kept) | R, readers | Verdicts |
|---|---|---|---|---|---|---|---|---|
| Pythia-1B | X1 | 0.984 | 65% | 0.46 / 0.38 / 0.27 | 55% (93%) | – | 50% | C pass, T pass, S pass, R pass |
| Qwen2.5-0.5B | X1 | 0.984 | 59% | 0.16 / 0.21 / 0.13 | 37% (85%) | – | 96% | C pass, T pass, S pass, R pass |
| OLMo-2-1B | X1 | 0.988 | 74% | 0.36 / 0.31 / 0.29 | 37% (73%) | 76% (57%) | 113% | C pass, T pass, S pass, X pass, R pass |
| Qwen3-1.7B | X3 | 0.988 | 70% | 0.25 / 0.18 / 0.13 | – | 44% (52%) | 78% | C pass, T pass, X pass, R pass |
| Qwen3-0.6B | X3 | 0.987 | 76% | 0.21 / 0.19 / 0.11 | – | 43% (42%) | 78% | C pass, T pass, X pass, R pass |
| Gemma-4-E2B | X3b | 0.987 | 68% | 0.39 / 0.38 / 0.31 | 44% (70%) | – | 50% | C pass, T pass, S pass, R pass |
| SmolLM2-1.7B | X3b | 0.986 | 73% | 0.23 / 0.22 / 0.18 | 36% (86%) | – | 48% | C pass, T pass, S pass, R pass |

| Model | Counters | Token correctors | Stored length / newline writers | Readers |
|---|---|---|---|---|
| Pythia-1B | L1H1, L1H6, L2H5, L3H0, L3H5, L6H3 | L0H0, L1H1, L1H6 | S: L3H5, L6H3, L9H4, L10H1, L1H1, L2H6 | L12H6, L9H0, L7H3 |
| Qwen2.5-0.5B | L2H1, L3H1, L3H2, L6H1 | L1H8, L1H9, L2H1, L3H1 | S: L2H1, L3H1, L3H2 | L6H4, L4H8, L6H6 |
| OLMo-2-1B | L6H2, L7H10, L11H4, L14H15 | L1H10, L0H5, L3H15 | S: L0H9, L1H10, L1H12, L3H7; X: L5H0 | L6H2, L7H10, L11H4 |
| Qwen3-1.7B | L4H0, L4H1, L5H13, L6H2, L7H15 | L4H1 | X: L5H12, L5H13, L6H2 | L7H14, L15H3, L17H6, L22H3 |
| Qwen3-0.6B | L4H0, L4H1, L5H13, L6H2, L7H15 | L4H1 | X: L5H12, L5H13, L6H2 | L7H14, L15H3, L17H6, L22H3 |
| Gemma-4-E2B | L6H3, L12H3 | L6H3 | S: L6H1, L6H3, L7H6 | L9H5, L12H3 |
| SmolLM2-1.7B | L5H21, L7H22, L9H7 | L5H21, L3H2 | S: L5H21, L9H7, L6H25, L2H17 | L11H21 |

| Model | Largest random-set share, C / S or X / R | Largest random token weight (any width) |
|---|---|---|
| Pythia-1B | 8% / 5% / 1% | 0.13 |
| Qwen2.5-0.5B | 0% / 9% / 0% | 0.05 |
| OLMo-2-1B | 6% / 5% / 4% | 0.05 |
| Qwen3-1.7B | 0% / 2% / 1% | 0.02 |
| Qwen3-0.6B | 1% / 2% / 1% | 0.06 |
| Gemma-4-E2B | 5% / 7% / 2% | 0.07 |
| SmolLM2-1.7B | 0% / 4% / 0% | 0.04 |

| Model | Heads in C and T | Heads in C and S or X | Heads in C and R | Heads in C, T and S or X |
|---|---|---|---|---|
| Pythia-1B | L1H1, L1H6 | L1H1, L3H5, L6H3 | none | L1H1 |
| Qwen2.5-0.5B | L2H1, L3H1 | L2H1, L3H1, L3H2 | none | L2H1, L3H1 |
| OLMo-2-1B | none | none | L6H2, L7H10, L11H4 | none |
| Qwen3-1.7B | L4H1 | L5H13, L6H2 | none | none |
| Qwen3-0.6B | L4H1 | L5H13, L6H2 | none | none |
| Gemma-4-E2B | L6H3 | L6H3 | L12H3 | L6H3 |
| SmolLM2-1.7B | L5H21 | L5H21, L9H7 | none | L5H21 |
| Models with at least one such head | 6 of 7 | 6 of 7 | 2 of 7 | 4 of 7 |

| Model | Token corrector | Newline attention share | Correlation with characters used |
|---|---|---|---|
| Pythia-1B | L0H0 | 0.07 | -0.87 |
| Pythia-1B | L1H1 | 0.11 | -0.50 |
| Pythia-1B | L1H6 | 0.17 | -0.91 |
| Qwen2.5-0.5B | L1H8 | 0.08 | -0.75 |
| Qwen2.5-0.5B | L1H9 | 0.04 | -0.46 |
| Qwen2.5-0.5B | L2H1 | 0.24 | -0.91 |
| Qwen2.5-0.5B | L3H1 | 0.10 | -0.87 |
| OLMo-2-1B | L1H10 | 0.13 | -0.50 |
| OLMo-2-1B | L0H5 | 0.06 | -0.54 |
| OLMo-2-1B | L3H15 | 0.04 | -0.57 |
| Qwen3-1.7B | L4H1 | 0.10 | -0.91 |
| Qwen3-0.6B | L4H1 | 0.10 | -0.90 |
| Gemma-4-E2B | L6H3 | 0.17 | -0.77 |
| SmolLM2-1.7B | L5H21 | 0.09 | +0.59 |
| SmolLM2-1.7B | L3H2 | 0.11 | -0.89 |
| All | 15 heads | | 14 of 15 below −0.30 |
