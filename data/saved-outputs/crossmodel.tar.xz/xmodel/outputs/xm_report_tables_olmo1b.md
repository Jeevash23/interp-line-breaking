| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1251 |
| AUROC | 0.988 |
| Separation | 3.422 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L6H2,L7H10,L11H4,L14H15 | 150 | -3.608 (-3.896, -3.331) | 73.5% (71.3%, 75.7%) | 0.7% (5.6%) | pass |
| S, stored length | L0H9,L1H10,L1H12,L3H7 | 150 | 1.395 (1.227, 1.568) | 36.7% (28.6%, 44.0%) | -2.0% (4.8%) | pass |
| X, stored length (second set) | L5H0 | 150 | 1.395 (1.227, 1.568) | 75.9% (71.4%, 80.8%) | 0.1% (1.2%) | pass |
| R, readers (Lw 3) | L6H2,L7H10,L11H4 | 150 | 0.836 (0.698, 0.978) | 112.7% (105.6%, 121.7%) | 0.4% (3.7%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| S: L0H9,L1H10,L1H12,L3H7 | 73.2% (68.7%, 77.2%) | 0.977 |
| X: L5H0 | 57.2% (53.7%, 60.9%) | 0.979 |

T, token correctors: L1H10,L0H5,L3H15 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 4978 | -0.001 (-0.045, 0.045) | 0.360 (0.309, 0.413) | 0.361 (0.315, 0.411) | -0.002 (0.052) | pass |
| 60 | 3015 | -0.018 (-0.054, 0.021) | 0.309 (0.259, 0.360) | 0.327 (0.275, 0.373) | -0.021 (0.031) | pass |
| 80 | 2125 | -0.029 (-0.070, 0.007) | 0.289 (0.243, 0.339) | 0.318 (0.278, 0.366) | -0.038 (0.005) | pass |

Verdicts: C pass, T pass, S pass, X pass, R pass
