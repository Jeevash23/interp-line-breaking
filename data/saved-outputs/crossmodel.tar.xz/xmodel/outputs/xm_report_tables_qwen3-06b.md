| Behaviour, width 60 | Value |
|---|---|
| Paragraphs | 60 |
| Decision points | 1229 |
| AUROC | 0.987 |
| Separation | 3.349 |
| Gate (AUROC ≥ 0.90) | pass |

| Test | Set | n | Effect (95% CI) | Share (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| C, counters | L4H0,L4H1,L5H13,L6H2,L7H15 | 150 | -3.481 (-3.761, -3.224) | 75.5% (71.5%, 79.9%) | 0.0% (0.6%) | pass |
| X, newline writers (no dissociation predicted) | L5H12,L5H13,L6H2 | 143 | 1.431 (1.252, 1.622) | 43.2% (38.3%, 47.7%) | -1.0% (2.3%) | pass |
| R, readers (Lw 6) | L7H14,L15H3,L17H6,L22H3 | 143 | 0.833 (0.707, 0.965) | 77.6% (73.6%, 82.3%) | 0.1% (0.7%) | pass |

| Newline-only ablation | Natural separation kept (95% CI) | AUROC |
|---|---|---|
| X: L5H12,L5H13,L6H2 | 42.0% (39.7%, 44.2%) | 0.975 |

T, token correctors: L4H1 ablated at every position.

| Width | Points | Intact (95% CI) | Ablated (95% CI) | Ablated minus intact (95% CI) | Random sets, mean (max) | Verdict |
|---|---|---|---|---|---|---|
| 40 | 4884 | 0.052 (0.020, 0.085) | 0.211 (0.179, 0.251) | 0.159 (0.128, 0.195) | 0.053 (0.061) | pass |
| 60 | 2970 | 0.006 (-0.033, 0.045) | 0.190 (0.159, 0.222) | 0.184 (0.148, 0.218) | 0.008 (0.017) | pass |
| 80 | 2053 | 0.010 (-0.027, 0.044) | 0.108 (0.089, 0.129) | 0.098 (0.071, 0.130) | 0.012 (0.018) | pass |

Verdicts: C pass, T pass, X pass, R pass
