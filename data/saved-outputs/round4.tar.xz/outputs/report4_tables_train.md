**D, the decision step.** Items: 100. Effects on log P(newline): COUNT 1.986, WIDTH 0.770, both 2.081 (interaction -0.675).

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| D1 | COUNT share lost, MLPs 14, 16, 18 frozen | 0.215 (0.202, 0.229) | >= 0.11, lower bound > 0 | pass |
| D1 | minus the mean of 10 random MLP triples (0.038) | 0.178 (0.167, 0.188) | lower bound > 0 | pass |
| D2 | COUNT share lost, MLPs 21, 23 frozen | -0.357 (-0.411, -0.309) | <= -0.10, upper bound < 0 | pass |
| D2 | WIDTH share lost, MLPs 21, 23 frozen | -0.373 (-0.487, -0.273) | <= -0.10, upper bound < 0 | pass |
| D3a | cosine after layer 12 minus after layer 6 (0.785 - 0.311) | 0.474 (0.385, 0.513) | >= 0.20, lower bound > 0 | pass |
| D3b | cosine after layer 12 | 0.785 | >= 0.65 | pass |
| D4 | largest head direct effect, COUNT: L17H1 0.967 (next L15H10 0.195) | | L17H1 | pass |
| D4 | largest head direct effect, WIDTH: L17H1 0.433 (next L8H15 0.142) | | L17H1 | pass |

D overall: pass

Cosine between the COUNT and WIDTH residual changes at the decision token, by layer: L5 0.00, L6 0.31, L7 0.34, L8 0.48, L9 0.61, L10 0.67, L11 0.75, L12 0.79, L13 0.80, L14 0.86, L15 0.83, L16 0.85, L17 0.80, L18 0.83, L19 0.82, L20 0.82, L21 0.75, L22 0.67, L23 0.74.

| Frozen at the decision token | COUNT share lost | WIDTH share lost |
|---|---|---|
| layers6-11 | 0.358 | 0.576 |
| layers12-17 | 0.427 | 0.448 |
| layers18-23 | -0.231 | -0.030 |
| all_heads | 0.434 | 1.000 |
| all_mlps | 0.098 | -0.191 |
| readers3 | 0.335 | 0.779 |
| L17H1 | 0.116 | 0.265 |
| MLP14_16_18 | 0.215 | 0.111 |
| MLP21_23 | -0.357 | -0.373 |
| random_mlp3_mean | 0.038 | -0.004 |

**S, sufficiency.** Paragraphs: 40; width items: 80. Intact separation 3.321, AUROC 0.979, width effect 1.788.

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| S1a | AUROC, late circuit only at the decision token (mean ablation) | 0.980 | >= 0.959 | pass |
| S1b | width effect kept, same | 0.656 (0.590, 0.728) | >= 0.33, lower bound > 0.256 (largest random circuit) | pass |
| S2 | separation kept, whole circuit (mean ablation) | 0.294 (0.264, 0.324) | >= 0.15, lower bound > 0.125 (largest random circuit) | pass |

S overall: pass

| Scope | Ablation | Separation kept | AUROC | Width effect kept |
|---|---|---|---|---|
| DEC | mean | 0.530 | 0.980 | 0.656 |
| DEC | resample | 0.559 | 0.970 | 0.570 |
| DEC | 5 random circuits, mean ablation | 0.184 to 0.496 | | 0.157 to 0.256 |
| EARLY | mean | 0.309 | 0.946 | 0.291 |
| EARLY | resample | 0.133 | 0.871 | 0.253 |
| EARLY | 5 random circuits, mean ablation | -0.011 to 0.029 | | 0.053 to 0.095 |
| BOTH | mean | 0.294 | 0.946 | 0.234 |
| BOTH | resample | 0.181 | 0.852 | 0.317 |
| BOTH | 5 random circuits, mean ablation | -0.008 to 0.125 | | 0.000 to 0.050 |

**G, the shape of the count** (split-half; half B's class means in half A's top directions).

| Width | After layer | Top direction: variance share | its linear R^2 | Second direction: linear / spline R^2 | its reliability | Overall linear R^2, labels shuffled |
|---|---|---|---|---|---|---|
| 40 | 5 | 0.767 | 0.985 | 0.006 / 0.539 | 0.899 | 0.009 |
| 40 | 6 | 0.779 | 0.904 | 0.113 / 0.896 | 0.971 | 0.006 |
| 60 | 5 | 0.709 | 0.952 | 0.019 / 0.425 | 0.783 | 0.028 |
| 60 | 6 | 0.719 | 0.806 | 0.172 / 0.821 | 0.928 | 0.037 |

| Width | Head | Peak at characters remaining | Monotone fit R^2 |
|---|---|---|---|
| 40 | L6H2 | 0 | 0.998 |
| 40 | L8H15 | 2 | 0.996 |
| 40 | L17H1 | 2 | 0.998 |
| 40 | L5H6 | 37 | 0.999 |
| 40 | L5H7 | 28 | 0.910 |
| 40 | L8H11 | 0 | 0.940 |
| 60 | L6H2 | 2 | 0.998 |
| 60 | L8H15 | 1 | 0.996 |
| 60 | L17H1 | 0 | 0.995 |
| 60 | L5H6 | 47 | 1.000 |
| 60 | L5H7 | 40 | 0.913 |
| 60 | L8H11 | 0 | 0.622 |

G1 pass, G2 pass, G3 pass; G overall: pass

**X, GPT-2 Small against Pythia-410M.**

| Part | Measure | GPT-2 Small | Pythia-410M | Threshold | Verdict |
|---|---|---|---|---|---|
| X1 | best-layer probe R^2, characters used | 0.818 | 0.918 | GPT-2 >= 0.70 | pass |
| X2 | largest count-shift effect over layers | 0.588 | 2.509 | GPT-2 <= 0.5 x Pythia | pass |
| X3 | behavioural width effect | 0.335 | 1.720 | GPT-2 <= 0.5 x Pythia | pass |
| X4 | largest line-start share among counting heads | 0.268 | 0.801 | GPT-2 < 0.30; Pythia >= 0.60 | pass |
| X5 | width patch at the newline: GPT-2 after layers 8-11 (largest absolute), Pythia after layer 8 | 0.038 | 0.408 | GPT-2 < 0.10; Pythia >= 0.25 | pass |

X overall: pass

GPT-2 Small: AUROC width 40 0.811, width 60 0.843; token coefficient -0.085 / -0.038; width items 100.
Pythia-410M: AUROC width 40 0.971, width 60 0.981; token coefficient 0.027 / 0.014; width items 100.
