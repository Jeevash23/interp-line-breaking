**D, the decision step.** Items: 100. Effects on log P(newline): COUNT 1.852, WIDTH 0.655, both 1.967 (interaction -0.540).

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| D1 | COUNT share lost, MLPs 14, 16, 18 frozen | 0.215 (0.203, 0.228) | >= 0.11, lower bound > 0 | pass |
| D1 | minus the mean of 10 random MLP triples (0.033) | 0.182 (0.172, 0.192) | lower bound > 0 | pass |
| D2 | COUNT share lost, MLPs 21, 23 frozen | -0.358 (-0.404, -0.315) | <= -0.10, upper bound < 0 | pass |
| D2 | WIDTH share lost, MLPs 21, 23 frozen | -0.442 (-0.552, -0.344) | <= -0.10, upper bound < 0 | pass |
| D3a | cosine after layer 12 minus after layer 6 (0.801 - 0.322) | 0.479 (0.407, 0.514) | >= 0.20, lower bound > 0 | pass |
| D3b | cosine after layer 12 | 0.801 | >= 0.65 | pass |
| D4 | largest head direct effect, COUNT: L17H1 0.917 (next L15H10 0.233) | | L17H1 | pass |
| D4 | largest head direct effect, WIDTH: L17H1 0.411 (next L8H15 0.125) | | L17H1 | pass |

D overall: pass

Cosine between the COUNT and WIDTH residual changes at the decision token, by layer: L5 0.00, L6 0.32, L7 0.35, L8 0.49, L9 0.62, L10 0.68, L11 0.76, L12 0.80, L13 0.81, L14 0.89, L15 0.86, L16 0.88, L17 0.82, L18 0.85, L19 0.86, L20 0.87, L21 0.76, L22 0.75, L23 0.76.

| Frozen at the decision token | COUNT share lost | WIDTH share lost |
|---|---|---|
| layers6-11 | 0.375 | 0.569 |
| layers12-17 | 0.435 | 0.481 |
| layers18-23 | -0.259 | -0.129 |
| all_heads | 0.437 | 1.000 |
| all_mlps | 0.074 | -0.240 |
| readers3 | 0.339 | 0.789 |
| L17H1 | 0.106 | 0.281 |
| MLP14_16_18 | 0.215 | 0.119 |
| MLP21_23 | -0.358 | -0.442 |
| random_mlp3_mean | 0.033 | -0.005 |

**S, sufficiency.** Paragraphs: 40; width items: 80. Intact separation 3.067, AUROC 0.978, width effect 1.651.

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| S1a | AUROC, late circuit only at the decision token (mean ablation) | 0.976 | >= 0.958 | pass |
| S1b | width effect kept, same | 0.727 (0.663, 0.804) | >= 0.33, lower bound > 0.280 (largest random circuit) | pass |
| S2 | separation kept, whole circuit (mean ablation) | 0.304 (0.279, 0.328) | >= 0.15, lower bound > 0.163 (largest random circuit) | pass |

S overall: pass

| Scope | Ablation | Separation kept | AUROC | Width effect kept |
|---|---|---|---|---|
| DEC | mean | 0.529 | 0.976 | 0.727 |
| DEC | resample | 0.520 | 0.966 | 0.674 |
| DEC | 5 random circuits, mean ablation | 0.186 to 0.514 | | 0.169 to 0.280 |
| EARLY | mean | 0.312 | 0.941 | 0.304 |
| EARLY | resample | 0.133 | 0.862 | 0.285 |
| EARLY | 5 random circuits, mean ablation | -0.021 to 0.020 | | 0.070 to 0.119 |
| BOTH | mean | 0.304 | 0.946 | 0.248 |
| BOTH | resample | 0.172 | 0.845 | 0.409 |
| BOTH | 5 random circuits, mean ablation | -0.016 to 0.163 | | -0.002 to 0.047 |

**G, the shape of the count** (split-half; half B's class means in half A's top directions).

| Width | After layer | Top direction: variance share | its linear R^2 | Second direction: linear / spline R^2 | its reliability | Overall linear R^2, labels shuffled |
|---|---|---|---|---|---|---|
| 40 | 5 | 0.738 | 0.990 | 0.009 / 0.568 | 0.858 | 0.010 |
| 40 | 6 | 0.755 | 0.913 | 0.074 / 0.935 | 0.966 | 0.007 |
| 60 | 5 | 0.689 | 0.945 | 0.001 / 0.619 | 0.857 | 0.016 |
| 60 | 6 | 0.707 | 0.811 | 0.100 / 0.896 | 0.954 | 0.026 |

| Width | Head | Peak at characters remaining | Monotone fit R^2 |
|---|---|---|---|
| 40 | L6H2 | 0 | 0.997 |
| 40 | L8H15 | 2 | 0.993 |
| 40 | L17H1 | 0 | 0.997 |
| 40 | L5H6 | 37 | 1.000 |
| 40 | L5H7 | 27 | 0.973 |
| 40 | L8H11 | 0 | 0.976 |
| 60 | L6H2 | 1 | 0.998 |
| 60 | L8H15 | 1 | 0.999 |
| 60 | L17H1 | 1 | 0.996 |
| 60 | L5H6 | 49 | 1.000 |
| 60 | L5H7 | 40 | 0.913 |
| 60 | L8H11 | 0 | 0.681 |

G1 pass, G2 pass, G3 pass; G overall: pass

**X, GPT-2 Small against Pythia-410M.**

| Part | Measure | GPT-2 Small | Pythia-410M | Threshold | Verdict |
|---|---|---|---|---|---|
| X1 | best-layer probe R^2, characters used | 0.809 | 0.915 | GPT-2 >= 0.70 | pass |
| X2 | largest count-shift effect over layers | 0.630 | 2.267 | GPT-2 <= 0.5 x Pythia | pass |
| X3 | behavioural width effect | 0.317 | 1.465 | GPT-2 <= 0.5 x Pythia | pass |
| X4 | largest line-start share among counting heads | 0.277 | 0.792 | GPT-2 <= 0.5 x Pythia; Pythia >= 0.60 | pass |
| X5 | width patch at the newline: GPT-2 after layers 8-11 (largest absolute), Pythia after layer 8 | 0.047 | 0.352 | GPT-2 < 0.10; Pythia >= 0.25 | pass |

X overall: pass

GPT-2 Small: AUROC width 40 0.807, width 60 0.852; token coefficient -0.022 / 0.015; width items 100.
Pythia-410M: AUROC width 40 0.968, width 60 0.978; token coefficient 0.039 / 0.021; width items 100.
