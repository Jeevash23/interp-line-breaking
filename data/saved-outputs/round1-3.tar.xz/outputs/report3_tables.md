**R1 and H3.** Token coefficient (95% paragraph-bootstrap interval).

| Width | Points | Intact | L5H7 ablated | L5H3 ablated | L5H11 ablated | L5H14 ablated | R1a | R1b | R1c |
|---|---|---|---|---|---|---|---|---|---|
| 40 | 5718 | 0.087 (0.046, 0.128) | 0.591 (0.522, 0.657) | 0.089 (0.049, 0.131) | 0.082 (0.042, 0.122) | 0.084 (0.043, 0.125) | fail | pass | pass |
| 60 | 3453 | 0.055 (0.024, 0.083) | 0.587 (0.539, 0.643) | 0.057 (0.026, 0.086) | 0.051 (0.021, 0.079) | 0.053 (0.022, 0.082) | pass | pass | pass |
| 80 | 2401 | 0.021 (-0.011, 0.052) | 0.474 (0.418, 0.536) | 0.021 (-0.010, 0.052) | 0.019 (-0.012, 0.050) | 0.019 (-0.012, 0.051) | pass | pass | pass |

Original H1 (all parts, all widths, frozen 0.10 limit): fail; H1a at width 40 under the 0.10 limit: fail
Round-3 prediction for width 40, intact lower bound above 0: pass
T1 (round-3 token-correction claim: H1b and H1c at all widths, H1a at widths 60 and 80, width-40 residual above 0): pass

| Width | L4H14 ablated | L4H14 minus intact (paired) | H3 | L4H14 + L5H7 ablated | Joint minus L5H7 alone (paired) |
|---|---|---|---|---|---|
| 40 | 0.198 (0.149, 0.252) | 0.111 (0.086, 0.135) | pass | 0.708 (0.633, 0.786) | 0.117 (0.094, 0.143) |
| 60 | 0.234 (0.199, 0.271) | 0.179 (0.154, 0.203) | pass | 0.658 (0.602, 0.723) | 0.071 (0.052, 0.092) |
| 80 | 0.217 (0.177, 0.261) | 0.197 (0.167, 0.227) | pass | 0.544 (0.485, 0.614) | 0.071 (0.054, 0.090) |

H3 overall: pass

**R2.** Width effect (n = 150): 0.667 (0.565, 0.770)

| Frozen at the decision token | Mediation share (95% CI) |
|---|---|
| L8H15 | 0.431 (0.394, 0.469) |
| L8H15, L17H1, L6H2 | 0.750 (0.709, 0.790) |
| 10 random triples, mean | 0.005 |

R2 overall: pass

**H4.** Width effect, intact (n = 150): 1.431 (1.267, 1.601)

| Newline-only ablation | Share of the width effect removed (95% CI) |
|---|---|
| COUNT4, every newline | 45.8% (40.9%, 50.5%) |
| COUNT4, last newline only | 58.3% (54.1%, 62.7%) |
| 10 random sets of 4 heads, mean | -1.5% |

| Natural text, width 60 (60 paragraphs) | Separation | AUROC | Kept |
|---|---|---|---|
| Intact | 3.084 | 0.876 | |
| COUNT4 at newlines only | 2.580 | 0.856 | 83.7% |
| COUNT4 at every position | 0.076 | 0.513 | 2.5% |

H4a pass, H4b pass, H4c pass, H4d pass; H4 overall: pass

**H5.** Width effect, eager attention (n = 150): 0.667 (0.565, 0.770)

| Head | Key only | Value only |
|---|---|---|
| L8H15 | 0.037 (-0.000, 0.075) | 0.294 (0.259, 0.331) |
| L17H1 | 0.105 (0.083, 0.131) | 0.020 (0.015, 0.028) |
| L8H11 | -0.042 (-0.050, -0.035) | -0.002 (-0.005, 0.002) |

L8H15 value minus key: 0.257 (0.202, 0.315); L17H1 key minus value: 0.085 (0.063, 0.110)

H5a pass, H5b pass; H5 overall: pass

**H6.** Coefficient of the previous line's token count (95% paragraph-bootstrap interval).

| Width | Points | Intact | L5H7 at newlines | L5H11 at newlines | L5H7 minus intact (paired) | L5H11 minus intact | H6a | H6b |
|---|---|---|---|---|---|---|---|---|
| 40 | 5718 | -0.013 (-0.045, 0.018) | -0.057 (-0.090, -0.026) | -0.012 (-0.043, 0.019) | -0.044 (-0.055, -0.032) | 0.001 | pass | pass |
| 60 | 3453 | -0.020 (-0.055, 0.018) | -0.089 (-0.121, -0.052) | -0.019 (-0.054, 0.019) | -0.069 (-0.087, -0.051) | 0.001 | pass | pass |
| 80 | 2401 | 0.009 (-0.018, 0.038) | -0.062 (-0.089, -0.033) | 0.009 (-0.018, 0.038) | -0.071 (-0.086, -0.057) | -0.000 | not assessed | not assessed |

H6 overall: pass
