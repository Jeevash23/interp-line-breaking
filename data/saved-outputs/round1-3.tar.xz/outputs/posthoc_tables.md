Tests in the family: 54. Holm at family-wise alpha 0.025 (one-sided). Largest difference between the mean-ablation re-run and the frozen outputs: 1.93e-08.

| Round | Part | One-sided p | Holm-adjusted p | Holds after Holm |
|---|---|---|---|---|
| 1 | H1a, width 40 | 0.1081 | 0.1081 | no |
| 1 | H1b, width 40 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H3, width 40 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H11, width 40 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H14, width 40 | 0.0001 | 0.0054 | yes |
| 1 | H1a, width 60 | 0.0013 | 0.0054 | yes |
| 1 | H1b, width 60 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H3, width 60 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H11, width 60 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H14, width 60 | 0.0001 | 0.0054 | yes |
| 1 | H1a, width 80 | 0.0001 | 0.0054 | yes |
| 1 | H1b, width 80 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H3, width 80 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H11, width 80 | 0.0001 | 0.0054 | yes |
| 1 | H1c L5H14, width 80 | 0.0001 | 0.0054 | yes |
| 1 | H2 positive control | 0.0001 | 0.0054 | yes |
| 1 | H2 L8H15 >= 0.25 | 0.0001 | 0.0054 | yes |
| 1 | H2 readers3 >= 0.50 | 0.0001 | 0.0054 | yes |
| 1 | H2 random mean < 0.15 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1a, width 40 | 0.0324 | 0.0648 | no |
| 2 (R1) | H1b, width 40 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H3, width 40 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H11, width 40 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H14, width 40 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1a, width 60 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1b, width 60 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H3, width 60 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H11, width 60 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H14, width 60 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1a, width 80 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1b, width 80 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H3, width 80 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H11, width 80 | 0.0001 | 0.0054 | yes |
| 2 (R1) | H1c L5H14, width 80 | 0.0001 | 0.0054 | yes |
| 2 (R2) | H2 positive control | 0.0001 | 0.0054 | yes |
| 2 (R2) | H2 L8H15 >= 0.25 | 0.0001 | 0.0054 | yes |
| 2 (R2) | H2 readers3 >= 0.50 | 0.0001 | 0.0054 | yes |
| 2 (R2) | H2 random mean < 0.15 | 0.0001 | 0.0054 | yes |
| 2 | H3, width 40 | 0.0001 | 0.0054 | yes |
| 2 | H3, width 60 | 0.0001 | 0.0054 | yes |
| 2 | H3, width 80 | 0.0001 | 0.0054 | yes |
| 2 | H4 positive control | 0.0001 | 0.0054 | yes |
| 2 | H4a | 0.0001 | 0.0054 | yes |
| 2 | H4b | 0.0001 | 0.0054 | yes |
| 2 | H4c | 0.0001 | 0.0054 | yes |
| 2 | H4d, newline-only kept >= 0.80 | 0.0004 | 0.0054 | yes |
| 2 | H4d, all-position kept < 0.30 | 0.0001 | 0.0054 | yes |
| 2 | H5 positive control | 0.0001 | 0.0054 | yes |
| 2 | H5a | 0.0001 | 0.0054 | yes |
| 2 | H5b | 0.0001 | 0.0054 | yes |
| 2 | H6a, width 40 | 0.0001 | 0.0054 | yes |
| 2 | H6b, width 40 | 0.0001 | 0.0054 | yes |
| 2 | H6a, width 60 | 0.0001 | 0.0054 | yes |
| 2 | H6b, width 60 | 0.0001 | 0.0054 | yes |

Parts holding after Holm: 52 of 54

| Split | Measure | Mean ablation | Resample ablation | Frozen criterion met with resample |
|---|---|---|---|---|
| validation | token coefficient, L5H7 ablated, width 40 | 0.584 (0.516, 0.664) | 0.485 (0.422, 0.558) | yes |
| validation | token coefficient, L4H14 ablated, width 40 | 0.201 (0.165, 0.242) | 0.175 (0.139, 0.215) | yes |
| validation | largest control change (L5H3, L5H11, L5H14), width 40 | 0.006 | 0.005 | yes |
| validation | token coefficient, L5H7 ablated, width 60 | 0.613 (0.542, 0.692) | 0.433 (0.376, 0.501) | yes |
| validation | token coefficient, L4H14 ablated, width 60 | 0.241 (0.204, 0.280) | 0.186 (0.145, 0.229) | yes |
| validation | largest control change (L5H3, L5H11, L5H14), width 60 | 0.002 | 0.001 | yes |
| validation | token coefficient, L5H7 ablated, width 80 | 0.468 (0.408, 0.547) | 0.342 (0.291, 0.404) | yes |
| validation | token coefficient, L4H14 ablated, width 80 | 0.217 (0.180, 0.257) | 0.153 (0.114, 0.194) | yes |
| validation | largest control change (L5H3, L5H11, L5H14), width 80 | 0.001 | 0.002 | yes |
| validation | width effect removed, COUNT4 at every newline | 0.500 (0.450, 0.548) | 0.385 (0.324, 0.440) | yes |
| validation | width effect removed, COUNT4 at last newline | 0.616 (0.572, 0.660) | 0.376 (0.319, 0.430) | yes |
| validation | width effect removed, random sets, mean | -0.021 | -0.013 | yes |
| validation | separation kept, COUNT4 newline-only / every position | 0.854 / 0.042 | 0.913 / 0.044 | yes |
| validation | previous-line token weight, L5H7 at newlines minus intact, width 40 | -0.043 (-0.055, -0.031) | -0.033 (-0.050, -0.016) | yes |
| validation | previous-line token weight, L5H7 at newlines minus intact, width 60 | -0.059 (-0.072, -0.045) | -0.048 (-0.061, -0.035) | yes |
| validation | previous-line token weight, L5H7 at newlines minus intact, width 80 | -0.058 (-0.070, -0.047) | -0.045 (-0.058, -0.033) | yes |
| test | token coefficient, L5H7 ablated, width 40 | 0.620 (0.549, 0.696) | 0.481 (0.419, 0.550) | yes |
| test | token coefficient, L4H14 ablated, width 40 | 0.205 (0.158, 0.255) | 0.195 (0.149, 0.245) | yes |
| test | largest control change (L5H3, L5H11, L5H14), width 40 | 0.004 | 0.002 | yes |
| test | token coefficient, L5H7 ablated, width 60 | 0.612 (0.542, 0.686) | 0.415 (0.353, 0.479) | yes |
| test | token coefficient, L4H14 ablated, width 60 | 0.257 (0.220, 0.292) | 0.188 (0.148, 0.229) | yes |
| test | largest control change (L5H3, L5H11, L5H14), width 60 | 0.004 | 0.004 | yes |
| test | token coefficient, L5H7 ablated, width 80 | 0.525 (0.471, 0.586) | 0.368 (0.323, 0.420) | yes |
| test | token coefficient, L4H14 ablated, width 80 | 0.224 (0.194, 0.257) | 0.154 (0.120, 0.188) | yes |
| test | largest control change (L5H3, L5H11, L5H14), width 80 | 0.002 | 0.001 | yes |
| test | width effect removed, COUNT4 at every newline | 0.464 (0.420, 0.510) | 0.356 (0.306, 0.405) | yes |
| test | width effect removed, COUNT4 at last newline | 0.613 (0.574, 0.653) | 0.422 (0.372, 0.469) | yes |
| test | width effect removed, random sets, mean | -0.012 | -0.008 | yes |
| test | separation kept, COUNT4 newline-only / every position | 0.863 / 0.078 | 0.902 / 0.036 | yes |
| test | previous-line token weight, L5H7 at newlines minus intact, width 40 | -0.050 (-0.060, -0.040) | -0.041 (-0.051, -0.032) | yes |
| test | previous-line token weight, L5H7 at newlines minus intact, width 60 | -0.075 (-0.091, -0.058) | -0.060 (-0.076, -0.041) | yes |
| test | previous-line token weight, L5H7 at newlines minus intact, width 80 | -0.067 (-0.078, -0.056) | -0.065 (-0.078, -0.050) | yes |
