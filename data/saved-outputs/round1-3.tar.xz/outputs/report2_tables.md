**R1 and H3.** Token coefficient (95% paragraph-bootstrap interval).

| Width | Points | Intact | L5H7 ablated | L5H3 ablated | L5H11 ablated | L5H14 ablated | R1a | R1b | R1c |
|---|---|---|---|---|---|---|---|---|---|
| 40 | 6654 | 0.057 (0.014, 0.103) | 0.620 (0.549, 0.695) | 0.058 (0.015, 0.104) | 0.053 (0.011, 0.099) | 0.055 (0.012, 0.101) | fail | pass | pass |
| 60 | 4114 | 0.028 (-0.008, 0.065) | 0.612 (0.540, 0.685) | 0.032 (-0.004, 0.068) | 0.025 (-0.010, 0.061) | 0.028 (-0.009, 0.065) | pass | pass | pass |
| 80 | 2828 | 0.005 (-0.022, 0.031) | 0.525 (0.471, 0.587) | 0.008 (-0.020, 0.033) | 0.005 (-0.021, 0.030) | 0.006 (-0.022, 0.032) | pass | pass | pass |

R1 overall: fail; R1a at width 40: fail

| Width | L4H14 ablated | L4H14 minus intact (paired) | H3 | L4H14 + L5H7 ablated | Joint minus L5H7 alone (paired) |
|---|---|---|---|---|---|
| 40 | 0.205 (0.159, 0.256) | 0.148 (0.126, 0.171) | pass | 0.766 (0.684, 0.855) | 0.146 (0.122, 0.172) |
| 60 | 0.257 (0.221, 0.291) | 0.228 (0.203, 0.250) | pass | 0.682 (0.610, 0.757) | 0.070 (0.049, 0.093) |
| 80 | 0.224 (0.193, 0.258) | 0.218 (0.189, 0.248) | pass | 0.601 (0.546, 0.664) | 0.076 (0.056, 0.098) |

H3 overall: pass

**R2.** Width effect (n = 150): 0.753 (0.656, 0.860)

| Frozen at the decision token | Mediation share (95% CI) |
|---|---|
| L8H15 | 0.452 (0.419, 0.485) |
| L8H15, L17H1, L6H2 | 0.742 (0.704, 0.782) |
| 10 random triples, mean | 0.004 |

R2 overall: pass

**H4.** Width effect, intact (n = 150): 1.616 (1.456, 1.773)

| Newline-only ablation | Share of the width effect removed (95% CI) |
|---|---|
| COUNT4, every newline | 46.4% (41.9%, 50.8%) |
| COUNT4, last newline only | 61.3% (57.4%, 65.1%) |
| 10 random sets of 4 heads, mean | -1.2% |

| Natural text, width 60 (60 paragraphs) | Separation | AUROC | Kept |
|---|---|---|---|
| Intact | 3.639 | 0.911 | |
| COUNT4 at newlines only | 3.139 | 0.891 | 86.3% |
| COUNT4 at every position | 0.279 | 0.540 | 7.7% |

H4a pass, H4b pass, H4c pass, H4d pass; H4 overall: pass

**H5.** Width effect, eager attention (n = 150): 0.753 (0.656, 0.860)

| Head | Key only | Value only |
|---|---|---|
| L8H15 | 0.054 (0.020, 0.088) | 0.271 (0.239, 0.304) |
| L17H1 | 0.120 (0.098, 0.145) | 0.018 (0.014, 0.023) |
| L8H11 | -0.055 (-0.072, -0.041) | 0.003 (-0.001, 0.006) |

L8H15 value minus key: 0.217 (0.166, 0.270); L17H1 key minus value: 0.102 (0.079, 0.126)

H5a pass, H5b pass; H5 overall: pass

**H6.** Coefficient of the previous line's token count (95% paragraph-bootstrap interval).

| Width | Points | Intact | L5H7 at newlines | L5H11 at newlines | L5H7 minus intact (paired) | L5H11 minus intact | H6a | H6b |
|---|---|---|---|---|---|---|---|---|
| 40 | 6654 | -0.014 (-0.052, 0.018) | -0.064 (-0.104, -0.028) | -0.015 (-0.052, 0.017) | -0.050 (-0.060, -0.040) | -0.001 | pass | pass |
| 60 | 4114 | -0.032 (-0.065, -0.000) | -0.107 (-0.145, -0.070) | -0.032 (-0.065, -0.000) | -0.075 (-0.092, -0.058) | 0.000 | pass | pass |
| 80 | 2828 | -0.005 (-0.042, 0.030) | -0.073 (-0.112, -0.035) | -0.005 (-0.042, 0.031) | -0.067 (-0.078, -0.056) | 0.000 | not assessed | not assessed |

H6 overall: pass
