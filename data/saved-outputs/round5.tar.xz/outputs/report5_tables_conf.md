## T: the token bias

| Text | Width | Points | Mean tokens on the line | Characters per token | Intact (95% CI) | L5H7 ablated (95% CI) | Rise when ablated (95% CI) | L5H6 line-start attention per token (95% CI) |
|---|---|---|---|---|---|---|---|---|
| English | 20 | 7713 | 3.0 | 4.15 | 0.162 (0.113, 0.208) | 0.601 (0.538, 0.665) | 0.439 (0.402, 0.479) | -0.0146 (-0.0178, -0.0112) |
| English | 30 | 7606 | 4.1 | 4.29 | 0.099 (0.061, 0.135) | 0.661 (0.603, 0.718) | 0.562 (0.517, 0.608) | -0.0092 (-0.0115, -0.0070) |
| English | 40 | 6045 | 5.8 | 4.54 | 0.050 (0.012, 0.090) | 0.578 (0.523, 0.632) | 0.529 (0.488, 0.566) | -0.0074 (-0.0094, -0.0054) |
| English | 60 | 3685 | 10.2 | 4.60 | 0.015 (-0.028, 0.057) | 0.523 (0.463, 0.587) | 0.508 (0.455, 0.564) | -0.0034 (-0.0059, -0.0009) |
| English | 80 | 2572 | 14.5 | 4.65 | 0.036 (0.000, 0.074) | 0.448 (0.382, 0.516) | 0.412 (0.366, 0.463) | -0.0038 (-0.0067, -0.0012) |
| English | 100 | 1898 | 18.7 | 4.67 | -0.020 (-0.056, 0.021) | 0.284 (0.225, 0.348) | 0.304 (0.260, 0.355) | -0.0043 (-0.0079, -0.0010) |
| English | 120 | 1439 | 23.1 | 4.67 | -0.006 (-0.043, 0.035) | 0.227 (0.169, 0.288) | 0.233 (0.202, 0.269) | -0.0130 (-0.0177, -0.0092) |
| code | 40 | 6928 | 7.2 | 3.80 | 0.061 (0.022, 0.102) | 0.298 (0.254, 0.348) | 0.238 (0.215, 0.264) | -0.0125 (-0.0158, -0.0092) |
| code | 60 | 4339 | 12.7 | 3.77 | 0.036 (0.005, 0.067) | 0.269 (0.231, 0.311) | 0.233 (0.212, 0.258) | -0.0187 (-0.0220, -0.0147) |
| German | 40 | 5411 | 8.4 | 3.05 | 0.019 (-0.015, 0.054) | 0.403 (0.358, 0.451) | 0.384 (0.348, 0.421) | -0.0082 (-0.0111, -0.0055) |
| German | 60 | 3206 | 14.8 | 3.11 | -0.004 (-0.045, 0.039) | 0.328 (0.277, 0.382) | 0.332 (0.296, 0.370) | -0.0071 (-0.0107, -0.0036) |

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| T1 | intact coefficient, English width 20 minus width 60 | 0.147 (0.089, 0.204) | >= 0.04, lower bound > 0; width-20 lower bound > 0 (0.113) | pass |
| T2 | rank correlation of the intact coefficient with mean tokens on the line, 11 text-width conditions | -0.909 | <= -0.50 | pass |
| T3 | L5H7-ablated coefficient, English width 20 minus width 100 | 0.316 (0.233, 0.391) | >= 0.15, lower bound > 0 | pass |
| T4 | L5H6 attention per token, English width 20 minus width 80 | -0.0108 (-0.0154, -0.0061) | <= -0.003, upper bound < 0 | pass |
| T5 | rise when L5H7 is ablated, in every condition (smallest 0.233) | 11 of 11 | each >= 0.10, lower bound > 0 | pass |

T overall: pass

## M: the late damping

Items: 100. Share of each source's effect lost when the named components are frozen at the decision token (negative: they work against the source).

| Source | Effect | MLPs 21, 23 frozen | same, final LayerNorm frozen | MLP23.736 and MLP21.1410 only | 20 damping neurons |
|---|---|---|---|---|---|
| COUNT | 1.885 | -0.415 (-0.473, -0.362) | -0.390 (-0.447, -0.337) | -0.406 (-0.454, -0.362) | -0.442 (-0.492, -0.395) |
| WIDTH | 0.578 | -0.545 (-0.680, -0.412) | -0.534 (-0.667, -0.408) | -0.523 (-0.628, -0.419) | -0.596 (-0.713, -0.477) |

Natural text, every position whose intact top token has probability 0.2 to 0.9: mean change in that token's log-probability (and in entropy) when the named components are mean-ablated at every position.

| Ablated | Top token | Positions | Change in log-probability (95% CI) | Change in entropy (95% CI) |
|---|---|---|---|---|
| MLP23.736 and MLP21.1410 | newline | 450 | 0.381 (0.359, 0.402) | -1.071 (-1.128, -1.010) |
| MLP23.736 and MLP21.1410 | other | 3198 | -0.047 (-0.058, -0.039) | -0.026 (-0.029, -0.022) |
| 20 damping neurons | newline | 450 | 0.281 (0.227, 0.329) | -0.991 (-1.075, -0.899) |
| 20 damping neurons | other | 3198 | -0.065 (-0.078, -0.054) | -0.029 (-0.044, -0.013) |
| MLPs 21 and 23 | newline | 450 | -0.055 (-0.224, 0.096) | -1.432 (-1.557, -1.300) |
| MLPs 21 and 23 | other | 3198 | -0.431 (-0.507, -0.360) | -0.426 (-0.548, -0.292) |

| Part | Measure | Value | Threshold | Verdict |
|---|---|---|---|---|
| M1 | damping by MLPs 21 and 23 with the final LayerNorm frozen: COUNT -0.390, WIDTH -0.534 (free: -0.415, -0.545) | | each <= -0.15, upper bound < 0, within 0.10 of the free value | pass |
| M2 | MLP23.736 and MLP21.1410 frozen alone: COUNT -0.406, WIDTH -0.523; as a share of the whole MLPs' damping 0.98, 0.96 | | each <= -0.15, upper bound < 0, >= 0.5 of the whole | pass |
| M3 | the two neurons ablated, natural text: newline 0.381 (0.359, 0.402); other tokens -0.047 (-0.058, -0.039) | | newline >= 0.15, lower bound > 0; other within 0.10, interval within 0.15 | pass |
| M4 | correlation of activation with the newline log-odds at decision points (3395 points): MLP23.736 0.833, MLP21.1410 0.776 | | each >= 0.50 | pass |

M overall: pass

## S: is a fuller circuit enough?

Paragraphs: 40; width items: 80. Intact separation 3.248, AUROC 0.978, width effect 1.443. Fidelity: 1 minus the circuit's squared error in the newline log-odds over all decision points, relative to the intact model's variance.

| Set | Ablation | Fidelity | Separation kept | AUROC | Width effect kept |
|---|---|---|---|---|---|
| round-4 circuit | mean | -0.164 | 0.305 | 0.949 | 0.264 |
| round-4 circuit | resample | -0.161 | 0.182 | 0.837 | 0.135 |
| + 4 components | mean | 0.531 | 0.453 | 0.945 | 0.379 |
| + 4 components | resample | 0.025 | 0.271 | 0.850 | 0.215 |
| + 8 | mean | 0.701 | 0.582 | 0.953 | 0.430 |
| + 8 | resample | 0.201 | 0.271 | 0.886 | 0.328 |
| + 16 | mean | 0.765 | 0.626 | 0.962 | 0.620 |
| + 16 | resample | 0.189 | 0.327 | 0.916 | 0.606 |
| + 24 (fuller circuit) | mean | 0.785 | 0.650 | 0.969 | 0.707 |
| + 24 (fuller circuit) | resample | 0.217 | 0.355 | 0.926 | 0.584 |
| 5 random sets, + 24 | mean | -0.831 to 0.117 | 0.242 to 0.358 | | 0.273 to 0.351 |
| 5 random sets, + 24 | resample | -0.272 to -0.177 | 0.195 to 0.246 | | 0.141 to 0.425 |

| Part | Measure | Value (95% CI) | Threshold | Verdict |
|---|---|---|---|---|
| S1 | fidelity, fuller circuit, mean ablation | 0.785 (0.763, 0.805) | >= 0.50, lower bound > largest random (0.117) | pass |
| S2 | separation kept, fuller minus round-4 circuit, mean ablation | 0.344 (0.315, 0.375) | >= 0.20, lower bound > 0 | pass |
| S3 | width effect kept, fuller circuit, mean ablation | 0.707 (0.612, 0.837) | >= 0.40, lower bound > largest random (0.351) | pass |
| S4 | resample ablation, fuller circuit: fidelity 0.217 (0.047, 0.359), separation kept 0.355 (0.316, 0.404) | | fidelity >= 0.15 and separation >= 0.25, lower bounds above the round-4 circuit's (-0.161, 0.182) | pass |

S overall: pass

## G: other widths and text types

Role battery of the cross-model study (counters C, token corrector T, stored width S, readers R), at one width per run. Values: the role's share (C, S, R) or the rise in the token coefficient when L5H7 is ablated (T), with 95% intervals; random-set means in brackets.

| Text | Width | AUROC | Separation | Counters C | Corrector T | Width effect | Stored width S | Readers R |
|---|---|---|---|---|---|---|---|---|
| English | 20 | 0.922 | 2.981 | 0.836 (0.836, 0.836) [-0.002]; holds (as predicted) | 0.458 (0.424, 0.499) [-0.003]; holds (as predicted) | 0.122 (-0.173, 0.393) | -8.125 (-65.277, 70.882) [-1.012]; does not (as predicted) | 2.036 (-2.831, 6.234) [0.006]; does not (as predicted) |
| English | 30 | 0.958 | 3.199 | 0.900 (0.851, 0.951) [0.001]; holds (as predicted) | 0.583 (0.534, 0.635) [-0.001]; holds (as predicted) | 1.159 (0.946, 1.374) | 0.094 (-0.101, 0.253) [-0.047]; does not (as predicted) | 0.668 (0.592, 0.725) [-0.004]; holds (as predicted) |
| English | 100 | 0.986 | 1.865 | 0.785 (0.761, 0.809) [0.000]; holds (as predicted) | 0.318 (0.274, 0.370) [0.001]; holds (as predicted) | 1.217 (1.031, 1.406) | 1.007 (0.954, 1.057) [0.364]; does not (as predicted) | 0.817 (0.783, 0.849) [0.002]; holds (as predicted) |
| English | 120 | 0.980 | 1.564 | 0.733 (0.707, 0.758) [-0.000]; holds (as predicted) | 0.241 (0.211, 0.278) [0.002]; holds (as predicted) | 0.990 (0.837, 1.143) | 1.042 (0.945, 1.143) [0.544]; does not (as predicted) | 0.777 (0.734, 0.810) [0.002]; holds (as predicted) |
| code | 40 | 0.871 | 1.946 | 0.647 (0.570, 0.732) [0.000]; holds (as predicted) | 0.311 (0.276, 0.349) [0.009]; holds (as predicted) | 0.628 (0.458, 0.796) | -0.516 (-0.912, -0.259) [-0.038]; does not (as predicted) | 0.303 (-1.461, 0.586) [-0.003]; does not (as predicted) |
| code | 60 | 0.925 | 2.197 | 0.763 (0.704, 0.828) [-0.002]; holds (as predicted) | 0.281 (0.252, 0.314) [0.003]; holds (as predicted) | 0.936 (0.733, 1.172) | 0.129 (0.013, 0.223) [-0.028]; does not (as predicted) | 0.717 (0.646, 0.782) [0.000]; holds (NOT as predicted) |
| German | 40 | 0.959 | 2.223 | 0.758 (0.716, 0.801) [-0.000]; holds (as predicted) | 0.409 (0.371, 0.449) [0.001]; holds (as predicted) | 0.470 (0.331, 0.627) | -0.580 (-1.078, -0.270) [-0.093]; does not (as predicted) | 0.597 (-0.463, 1.186) [-0.011]; does not (as predicted) |
| German | 60 | 0.971 | 1.843 | 0.738 (0.701, 0.777) [-0.000]; holds (as predicted) | 0.352 (0.316, 0.390) [0.000]; holds (as predicted) | 0.649 (0.533, 0.772) | 0.267 (0.181, 0.342) [0.004]; holds (as predicted) | 0.845 (0.741, 0.954) [0.002]; holds (as predicted) |

| Part | Prediction | Result | Threshold | Verdict |
|---|---|---|---|---|
| G1 | line-breaking works in every condition | AUROC 0.871 at the lowest | AUROC >= 0.80 in all 8 | pass |
| G2 | the counters and the token corrector hold in every condition | 16 of 16 | all 16 hold | pass |
| G3 | the width roles follow the predicted pattern (readers hold at English widths 30, 100 and 120 and German 60, not at English 20, code 40 and 60 or German 40; the stored width at the newline holds only in German at 60) | 15 of 16 cells as predicted | >= 13 of 16 | pass |

G overall: pass

